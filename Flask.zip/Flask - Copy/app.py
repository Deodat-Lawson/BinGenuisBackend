import base64
import datetime
import os
from io import BytesIO

import openai
from PIL import Image
from flask import Flask, render_template, request
from flask_cors import CORS

prompt = ""

app = Flask(__name__)

CORS(app)

UPLOAD_FOLDER = r'C:\Users\timot\OneDrive - Johns Hopkins\hackathonProject\models\research\imagedata'

openai.api_key = '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'


def get_completion(prompt_data, model="gpt-4"):
    instructed_prompt = "How to dispose "+prompt_data+" Give a short and concise response, make your response 3 to 5 sentences and less than 150 characters long. No bullet points. Mention whether the trash is recyclable or not and which bin to put it in, if the trash could be recyclable or not, make a judgement based on factual evidence and only mention your judgement. Do not mention yourself as a AI assistant or local laws or guidelines or such. Assume that there is a paper bin that accepts paper or cardbox. The recycling is the leftmost one and is greem, the incinerate one is the second left one and is gray, the paper one is the second right one and is blue, the compost one is the rightmost one and is yellow. Mention which bin to put the trash in by directions. Also mention what to do before recycling. remember that plastic needs to be placed in the incinerate bin if it is plastic bag, if its plastic bottle put it in the recycle bin. If it's other trash don't mention it's plastic"
    messages = [{"role": "user", "content": instructed_prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=0,
    )
    return response.choices[0].message["content"]


@app.route('/')
def index():  # put application's code here
    return render_template('index.html')


@app.route('/success', methods=['POST'])
def success():
    if request.method == 'POST':
        f = request.files['files']
        # f.save(f.filename)
        f.save(os.path.join(app.config['UPLOAD_FOLDER'], f.filename))
        return render_template('success.html', name=f.filename)


@app.route('/upload_image', methods=['POST'])
def upload_image():
    # try:
    # Receive the image data
    f = request.form['files']
    b64data = f.split(',')
    image_data = b64data[1]
    image_data_string = base64.b64decode(image_data)
    im = Image.open(BytesIO(image_data_string))
    im.save(UPLOAD_FOLDER + "\\test_" + datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_x%S") + ".png", 'PNG')

    response_string = "Image received and processed successfully!"
    return response_string


@app.route('/return_prompt', methods=['POST'])
def return_prompt():
    global prompt
    if request.form['is_tf'] == "True":
        prompt = request.form['predicted_class']
        print(prompt)
        response_string = "result received"
        return response_string

    else:
        result = get_completion(prompt)
        returnDict = {
            'prompt': prompt,
            'result': result
        }
        return returnDict


# except Exception as e:
#    return str(e), 400


if __name__ == '__main__':
    app.run()
